﻿//include http://code.jquery.com/jquery-1.10.2.min.js

function showImageProfile(imgInput) {
    if (imgInput.files[0] && imgInput.files) {
        var imgDir = new FileReader();
        imgDir.onload = function (e) {
            $('#imgProfile').attr('src', e.target.result);
        }
        imgDir.readAsDataURL(imgInput.files[0]);
    }
}

function showImageStock(imgInput, imageId) {
    if (imgInput.files[0] && imgInput.files) {
        var imgDir = new FileReader();
        imgDir.onload = function (e) {
            $('#imgStock').attr('src', e.target.result);
            $('#magGlass').attr('style',
                "background-image: url('" + e.target.result +
                "'); background-repeat: no-repeat; " +
                "background-size: 612.5px 612.5px; " +
                "left: 54.9833px; " +
                "top: 77.6px; " +
                "background - position: -187.971px - 227.55px; "
            );
        }
        imgDir.readAsDataURL(imgInput.files[0]);
    }
}

//not longer used
function resetMagnify(imageId, zoomModify, imgDirSrc) {
    //const glass = document.getElementsByClassName("image-magnify-glass");
    //glass.remove();
    //document.write("worked!");
    glass = document.getElementById("magGlass");
    glass.remove();
    //imageMagnifyChange(imageId, zoomModify, imgDirSrc);
}

function imageMagnify(imageId, zoomModify) {
    var _imageId = document.getElementById(imageId);
    var glass = document.createElement("glass");
    var width;
    var height;
    var offset;

    glass.setAttribute("class", "image-magnify-glass");
    glass.setAttribute("id", "magGlass");

    _imageId.parentElement.insertBefore(glass, _imageId);

    glass.style.backgroundImage = "url(\"" + _imageId.src + "\")";
    glass.style.backgroundSize = (_imageId.width * zoomModify) + "px " + (_imageId.height * zoomModify) + "px";

    offset = zoomModify;
    width = glass.offsetWidth + 240 / 2;
    height = glass.offsetHeight + 240 / 2;

    glass.addEventListener("mousemove", moveMagnifier);
    _imageId.addEventListener("mousemove", moveMagnifier);

    function moveMagnifier(event) {
        var position;
        var xPosition;
        var yPosition;

        event.preventDefault();

        position = getCursorPosition(event);

        xPosition = position.xPosition;
        yPosition = position.yPosition;

        if (xPosition > _imageId.width - (width / zoomModify)) {
            xPosition = _imageId.width - (width / zoomModify);
        }
        if (xPosition < width / zoomModify) {
            xPosition = width / zoomModify;
        }
        if (yPosition > _imageId.height - (height / zoomModify)) {
            yPosition = _imageId.height - (height / zoomModify);
        }
        if (yPosition < height / zoomModify) {
            yPosition = height / zoomModify;
        }

        glass.style.left = (xPosition - width) + "px";
        glass.style.top = (yPosition - height) + "px";

        glass.style.backgroundPosition = "-" + ((xPosition * zoomModify) - width + offset) + "px -" + ((yPosition * zoomModify) - height + offset) + "px";
    }

    function getCursorPosition(event) {
        var a;
        var xPosition = 0;
        var yPosition = 0;

        event = event || window.event;

        a = _imageId.getBoundingClientRect();

        xPosition = event.pageX - a.left;
        yPosition = event.pageY - a.top;

        xPosition = xPosition - window.pageXOffset;
        yPosition = yPosition - window.pageXOffset;

        return { xPosition: xPosition, yPosition: yPosition };
    }
}
