﻿
function checkClick(objReferencesCheckbox) {
    var row = objReferencesCheckbox.parentNode.parentNode;
    var gridView = row.parentNode;
    var inputList = gridView.getElementsByTagName("input");

    for (var i = 0; i < inputList.length;i++) {
        var headerCheckBox = inputList[0];
        var checked = true;

        if (inputList[i].type == "checkbox" && inputList[i] != headerCheckBox) {
            if (!inputList[i].checked) {
                checked = false;
                break;
            }
        }
    }
    headerCheckBox.checked = checked;
}

function checkAll(objReferencesCheckbox) {
    var gridView = objReferencesCheckbox.parentNode.parentNode.parentNode;
    var inputList = gridView.getElementsByTagName("input");

    for (var i = 0; i < inputList.length; i++) {
        var row = inputList[i].parentNode.parentNode;
        if (inputList[i].type == "checkbox" && objReferencesCheckbox != inputList[i]) {
            if (objReferencesCheckbox.checked) {
                inputList[i].checked = true;
            }
            else {
                inputList[i].checked = false;
            }
        }
    }
}
