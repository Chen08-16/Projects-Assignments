﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;
using System.Web.UI.DataVisualization.Charting;
using System.Configuration;

namespace StockManagementSystem.Forms
{
    public partial class DashboardOwner : System.Web.UI.Page
    {
        private SqlConnection connectSql;
        private SqlCommand cardTotalQuantityCmd;
        private SqlCommand cardTotalPriceCmd;
        private SqlCommand cardNumCategoryCmd;
        private SqlCommand cardNumBrandCmd;
        private SqlCommand cardNumRunningLowCmd;
        private SqlCommand cardNumOutofStockCmd;
        private SqlCommand stocksCmd;
        private SqlCommand stocksTopMostCmd;
        private SqlCommand stocksTopLeastCmd;
        private SqlCommand stocksCategoryCmd;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user_name"] != null && Session["password"] != null)
            {
                //Response.Write("<script>window.alert('Login Sucessful!')</script>"); testing line
                Response.ClearHeaders();
                Response.AddHeader("Cache-Control", "no-cache, no-store, max-age=0, must-revalidate");
                Response.AddHeader("Pragma", "no-cache");

                //Handle privileges who can access this page
                if ((string)Session["privilege"] != "Owner")
                {
                    Response.Write("<script>window.alert('Access Denied!')</script>");

                    if ((string)Session["privilege"] == "Admin")
                    {
                        Response.Redirect("~/Forms/DashboardAdmin.aspx");
                    }
                    else
                    {
                        Response.Redirect("~/Forms/DashboardUser.aspx");
                    }
                }
            }
            else
            {
                Response.Write("<script>window.alert('Login Failed!')</script>");
                Response.Redirect("~/Forms/Login.aspx");
            }

            if (!IsPostBack)
            {
                string connectStr = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|StockDatabase.mdf";
                connectSql = new SqlConnection(connectStr);

                try
                {
                    connectSql.Open();
                }
                catch (SqlException ex)
                {
                    Response.Write("<script>window.alert('SQL connection Failed!')</script>");
                }

                string stocksStr = "SELECT * FROM Stocks";
                stocksCmd = new SqlCommand(stocksStr, connectSql);

                string stocksTopMostStr = "SELECT * FROM Stocks WHERE" +
                                          "(" +
                                          "Quantity IN" +
                                          "(SELECT TOP (5) Quantity " +
                                          "FROM Stocks " +
                                          "GROUP BY Quantity " +
                                          "ORDER BY Quantity DESC" +
                                          ")" +
                                          ") ORDER BY Quantity DESC";
                stocksTopMostCmd = new SqlCommand(stocksTopMostStr, connectSql);

                string stocksTopLeastStr = "SELECT * FROM Stocks WHERE" +
                                          "(" +
                                          "Quantity IN" +
                                          "(SELECT TOP (5) Quantity " +
                                          "FROM Stocks " +
                                          "GROUP BY Quantity " +
                                          "ORDER BY Quantity ASC" +
                                          ")" +
                                          ") ORDER BY Quantity ASC";
                stocksTopLeastCmd = new SqlCommand(stocksTopLeastStr, connectSql);

                string stocksCategoryStr = "SELECT Category, COUNT(Category) FROM Stocks Group by Category";
                stocksCategoryCmd = new SqlCommand(stocksCategoryStr, connectSql);

                cardsDatasetLoad();
                bindChart();
                connectSql.Close();
            }
        }

        protected void chartStock_Click(object sender, ImageMapEventArgs e)
        {

        }

        private void cardsDatasetLoad()
        {
            ///System.InvalidCastException: 'Object cannot be cast from DBNull to other types.'
            try
            {
                string cardTotalQuantityStr = "SELECT SUM(Quantity) AS Total FROM Stocks";
                cardTotalQuantityCmd = new SqlCommand(cardTotalQuantityStr, connectSql);
                int cardTotalQuantityInt = Convert.ToInt32(cardTotalQuantityCmd.ExecuteScalar());
                lblQuantity.Text = cardTotalQuantityInt.ToString();

                string cardTotalPriceStr = "SELECT SUM(Quantity * Price) AS Total FROM Stocks";
                cardTotalPriceCmd = new SqlCommand(cardTotalPriceStr, connectSql);
                string cardTotalPriceString = Convert.ToString(cardTotalPriceCmd.ExecuteScalar());
                lblPrice.Text = "RM" + cardTotalPriceString;

                string cardNumCategoryStr = "SELECT COUNT(Total) FROM (SELECT COUNT(1) AS Total FROM Stocks Group By Category) AS CatCount";
                cardNumCategoryCmd = new SqlCommand(cardNumCategoryStr, connectSql);
                int cardNumCategoryInt = Convert.ToInt32(cardNumCategoryCmd.ExecuteScalar());
                lblCategories.Text = cardNumCategoryInt.ToString();

                string cardNumBrandStr = "SELECT COUNT(DISTINCT(Brand)) FROM Stocks";
                cardNumBrandCmd = new SqlCommand(cardNumBrandStr, connectSql);
                int cardNumBrandInt = Convert.ToInt32(cardNumBrandCmd.ExecuteScalar());
                lblBrands.Text = cardNumBrandInt.ToString();

                string cardNumRunningLowStr = "SELECT COUNT(1) AS Total FROM Stocks WHERE StockStatus = 'Running Low'";
                cardNumRunningLowCmd = new SqlCommand(cardNumRunningLowStr, connectSql);
                int cardNumRunningLowInt = Convert.ToInt32(cardNumRunningLowCmd.ExecuteScalar());
                lblRunningLow.Text = cardNumRunningLowInt.ToString();

                string cardNumOutofStockStr = "SELECT COUNT(1) AS Total FROM Stocks WHERE StockStatus = 'Out of Stock'";
                cardNumOutofStockCmd = new SqlCommand(cardNumOutofStockStr, connectSql);
                int cardNumOutofStockInt = Convert.ToInt32(cardNumOutofStockCmd.ExecuteScalar());
                lblOutofStock.Text = cardNumOutofStockInt.ToString();
            }
            catch (InvalidCastException e)
            {
                lblQuantity.Text = "No Data";
                lblPrice.Text = "No Data";
                lblCategories.Text = "No Data";
                lblBrands.Text = "No Data";
                lblRunningLow.Text = "No Data";
                lblOutofStock.Text = "No Data";
                return;
            }
        }

        private void bindChart()
        {
            //Quantity of current stocks Chart
            SqlDataAdapter adapter = new SqlDataAdapter(stocksCmd);
            DataSet dataSet = new DataSet();
            adapter.Fill(dataSet);

            DataTable ChartData = dataSet.Tables[0];

            string[] xPointMemberQuantity = new string[ChartData.Rows.Count];
            int[] yPointMemberQuantity = new int[ChartData.Rows.Count];

            string[] xPointEmpty = new string[1];
            int[] yPointEmpty = new int[1];

            for (int i = 0; i < ChartData.Rows.Count; i++)
            {
                xPointMemberQuantity[i] = ChartData.Rows[i]["StockName"].ToString();
                yPointMemberQuantity[i] = Convert.ToInt32(ChartData.Rows[i]["Quantity"]);
            }

            chartStock.Series[0].Points.DataBindXY(xPointMemberQuantity, yPointMemberQuantity);
            chartStock.ChartAreas[0].AxisX.Interval = 1;
            chartStock.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            chartStock.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chartStock.ChartAreas[0].AxisX.IsLabelAutoFit = false;
            chartStock.ChartAreas[0].AxisY.MinorGrid.Enabled = false;
            chartStock.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chartStock.Series[0].BorderWidth = 10;
            chartStock.Series[0].ChartType = SeriesChartType.Column;
            chartStock.Series[0].IsValueShownAsLabel = true;

            if (chartStock.Series[0].Points.Count == 0)
            {
                xPointEmpty[0] = "No Data";
                yPointEmpty[0] = 0;
                chartStock.Series[0].Points.DataBindXY(xPointEmpty, yPointEmpty);
            }

            //Top 5 Most Quantity Chart
            adapter = new SqlDataAdapter(stocksTopMostCmd);
            dataSet = new DataSet();
            adapter.Fill(dataSet);

            ChartData = dataSet.Tables[0];

            string[] xPointMemberTopMost = new string[ChartData.Rows.Count];
            int[] yPointMemberTopMost = new int[ChartData.Rows.Count];

            for (int i = 0; i < ChartData.Rows.Count; i++)
            {
                xPointMemberTopMost[i] = ChartData.Rows[i]["StockName"].ToString();
                yPointMemberTopMost[i] = Convert.ToInt32(ChartData.Rows[i]["Quantity"]);
            }

            chartStockTopMost.Series[0].Points.DataBindXY(xPointMemberTopMost, yPointMemberTopMost);
            chartStockTopMost.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            chartStockTopMost.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chartStockTopMost.ChartAreas[0].AxisX.IsLabelAutoFit = false;
            chartStockTopMost.ChartAreas[0].AxisY.MinorGrid.Enabled = false;
            chartStockTopMost.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chartStockTopMost.Series[0].BorderWidth = 10;
            chartStockTopMost.Series[0].ChartType = SeriesChartType.Column;
            chartStockTopMost.Series[0].IsValueShownAsLabel = true;

            if (chartStockTopMost.Series[0].Points.Count == 0)
            {
                xPointEmpty[0] = "No Data";
                yPointEmpty[0] = 0;
                chartStockTopMost.Series[0].Points.DataBindXY(xPointEmpty, yPointEmpty);
            }

            //Top 5 Least Quantity Chart
            adapter = new SqlDataAdapter(stocksTopLeastCmd);
            dataSet = new DataSet();
            adapter.Fill(dataSet);

            ChartData = dataSet.Tables[0];

            string[] xPointMemberTopLeast = new string[ChartData.Rows.Count];
            int[] yPointMemberTopLeast = new int[ChartData.Rows.Count];

            for (int i = 0; i < ChartData.Rows.Count; i++)
            {
                xPointMemberTopLeast[i] = ChartData.Rows[i]["StockName"].ToString();
                yPointMemberTopLeast[i] = Convert.ToInt32(ChartData.Rows[i]["Quantity"]);
            }

            chartStockTopLeast.Series[0].Points.DataBindXY(xPointMemberTopLeast, yPointMemberTopLeast);
            chartStockTopLeast.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            chartStockTopLeast.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chartStockTopLeast.ChartAreas[0].AxisX.IsLabelAutoFit = false;
            chartStockTopLeast.ChartAreas[0].AxisY.MinorGrid.Enabled = false;
            chartStockTopLeast.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chartStockTopLeast.Series[0].BorderWidth = 10;
            chartStockTopLeast.Series[0].ChartType = SeriesChartType.Column;
            chartStockTopLeast.Series[0].IsValueShownAsLabel = true;

            if (chartStockTopLeast.Series[0].Points.Count == 0)
            {
                xPointEmpty[0] = "No Data";
                yPointEmpty[0] = 0;
                chartStockTopLeast.Series[0].Points.DataBindXY(xPointEmpty, yPointEmpty);
            }

            //Category List Chart
            adapter = new SqlDataAdapter(stocksCategoryCmd);
            dataSet = new DataSet();
            adapter.Fill(dataSet);

            ChartData = dataSet.Tables[0];

            string[] xPointMemberCategory = new string[ChartData.Rows.Count];
            int[] yPointMemberCategory = new int[ChartData.Rows.Count];

            for (int i = 0; i < ChartData.Rows.Count; i++)
            {
                xPointMemberCategory[i] = ChartData.Rows[i]["Category"].ToString();
                yPointMemberCategory[i] = Convert.ToInt32(ChartData.Rows[i][1]);
            }

            chartStockCategory.Series[0].Points.DataBindXY(xPointMemberCategory, yPointMemberCategory);
            chartStockCategory.Series[0].ChartType = SeriesChartType.Pie;
            chartStockCategory.Palette = ChartColorPalette.SeaGreen;

            chartStockCategory.Series[0]["PieLabelStyle"] = "Outside";
            chartStockCategory.Series[0].BorderWidth = 1;
            chartStockCategory.Series[0].BorderDashStyle = ChartDashStyle.Solid;
            chartStockCategory.Series[0].BorderColor = System.Drawing.Color.FromArgb(200, 30, 30, 30);

            foreach (DataPoint point in chartStockCategory.Series[0].Points)
            {
                point.Label = "#PERCENT\n#VALX";
            }

            if (chartStockCategory.Series[0].Points.Count == 0)
            {
                xPointEmpty[0] = "No Data";
                yPointEmpty[0] = 0;
                chartStockCategory.Series[0].Points.DataBindXY(xPointEmpty, yPointEmpty);
            }
        }

        protected void linkLogout_Click(object sender, EventArgs e)
        {
            Session.Remove("user_name");
            Session.Remove("password");
            Session.Remove("privilege");
            Session.RemoveAll();
            Response.Redirect(Request.RawUrl);
        }
    }
}