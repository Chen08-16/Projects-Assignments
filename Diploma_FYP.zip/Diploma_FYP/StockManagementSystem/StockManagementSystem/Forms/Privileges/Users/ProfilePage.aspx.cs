﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace StockManagementSystem.Forms.Privileges.Users
{
    public partial class ProfilePage : System.Web.UI.Page
    {
        private SqlConnection connectSql;
        private SqlCommand userAccountCmd;

        private SqlDataAdapter adapter;
        private DataSet dataSet;
        private string dataKey = "Check";
        private DataTable dataTable;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user_name"] != null && Session["password"] != null)
            {
                //Response.Write("<script>window.alert('Login Sucessful!')</script>"); testing line
                Response.ClearHeaders();
                Response.AddHeader("Cache-Control", "no-cache, no-store, max-age=0, must-revalidate");
                Response.AddHeader("Pragma", "no-cache");

                loadDatabase();

                //Remove Administrator linkbutton if privilege is not Owner and Admin
                if ((string)Session["privilege"] != "Owner" && (string)Session["privilege"] != "Admin")
                {
                    linkAdminPage.Visible = false;
                }
            }
            else
            {
                Response.Write("<script>window.alert('Login Failed!')</script>");
                Response.Redirect("~/Forms/Login.aspx");
            }
            connectSql.Close();
        }

        protected void linkBack_Click(object sender, EventArgs e)
        {
            //DataRow dataRow = dataTable.Rows[0];
            //string user_privilege = (string)dataRow["Privileges"];

            Response.Redirect("~/Forms/Dashboard" + Session["privilege"].ToString() + ".aspx");
        }

        private void loadDatabase()
        {
            string connectStr = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|AccountDatabase.mdf";
            connectSql = new SqlConnection(connectStr);

            try
            {
                connectSql.Open();
            }
            catch (SqlException ex)
            {
                Response.Write("<script>window.alert('SQL connection Failed!')</script>");
            }

            string searchUserAccountStr = "SELECT * FROM UserAccounts WHERE Id = @user_id";
            userAccountCmd = new SqlCommand(searchUserAccountStr, connectSql);

            userAccountCmd.Parameters.Clear();
            userAccountCmd.Parameters.AddWithValue("user_id", (string)Session["user_id"]);

            adapter = new SqlDataAdapter(userAccountCmd);
            dataSet = new DataSet();
            adapter.Fill(dataSet, dataKey);

            dataTable = dataSet.Tables[dataKey];

            if (dataTable.Rows.Count == 0)
            {
                //Just Do Nothing
            }
            else
            {
                DataRow dataRow = dataTable.Rows[0];
                
                txtUserNameProfile.Text = dataRow["Name"].ToString();
                txtEmailProfile.Text = dataRow["Email"].ToString();
                txtDescription.Text = dataRow["Description"].ToString();

                if (dataRow["ProfileImage"].ToString() != null)
                {
                    imgProfile.ImageUrl = dataRow["ProfileImage"].ToString();
                }
            }
        }

        protected void linkLogout_Click(object sender, EventArgs e)
        {
            Session.Remove("user_name");
            Session.Remove("password");
            Session.Remove("privilege");
            Session.RemoveAll();
            Response.Redirect(Request.RawUrl);
        }

        protected void linkAdminPage_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Forms/Privileges/" + Session["privilege"].ToString() + "/AdministratorPage.aspx");
        }
    }
}