﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;

namespace StockManagementSystem.Forms.Privileges.Users
{
    public partial class SettingPage : System.Web.UI.Page
    {
        private SqlConnection connectSql;
        private SqlCommand displayProfileCmd;
        private SqlCommand checkAccountNameUpdateCmd;
        private SqlCommand updateProfileCmd;
        private SqlCommand updateProfileWithoutPasswordCmd;

        private SqlDataAdapter adapter;
        private DataSet dataSet;
        private string dataKey = "Check";
        private DataTable dataTable;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user_name"] != null && Session["password"] != null)
            {
                Response.ClearHeaders();
                Response.AddHeader("Cache-Control", "no-cache, no-store, max-age=0, must-revalidate");
                Response.AddHeader("Pragma", "no-cache");

                //Remove Administrator linkbutton if privilege is not Owner and Admin
                if ((string)Session["privilege"] != "Owner" && (string)Session["privilege"] != "Admin")
                {
                    linkAdminPage.Visible = false;
                }
            }
            else
            {
                Response.Write("<script>window.alert('Login Failed!')</script>");
                Response.Redirect("~/Forms/Login.aspx");
            }

            //Remove Administrator linkbutton if privilege is not Owner and Admin
            if ((string)Session["privilege"] != "Owner" && (string)Session["privilege"] != "Admin")
            {
                linkAdminPage.Visible = false;
            }

            loadDatabase();

            string checkAccountNameUpdateStr = "SELECT Id,Name FROM UserAccounts WHERE Name = @user_name_exist AND NOT Id = @user_id";
            checkAccountNameUpdateCmd = new SqlCommand(checkAccountNameUpdateStr, connectSql);

            string updateProfileStr = "UPDATE UserAccounts SET Name = @user_name, Password = @user_password, " +
                "Email = @user_email, ProfileImage = @user_image, Description = @user_description WHERE Id = @user_id";
            updateProfileCmd = new SqlCommand(updateProfileStr, connectSql);

            string updateProfileWithoutPasswordStr = "UPDATE UserAccounts SET Name = @user_name, Email = @user_email, " +
                "ProfileImage = @user_image, Description = @user_description WHERE Id = @user_id";
            updateProfileWithoutPasswordCmd = new SqlCommand(updateProfileWithoutPasswordStr, connectSql);
        }

        protected void btnApplyEdit_Click(object sender, EventArgs e)
        {
            string user_name = txtUserNameProfile.Text;
            string user_old_password = txtOldPassword.Text;
            string user_new_password = txtNewPassword.Text;
            string user_confirm_password = txtConfirmPassword.Text;
            string user_email = txtEmailProfile.Text;
            string user_description = txtDescription.Text;

            string profile_image_filename;
            string profile_image_path;

            checkAccountNameUpdateCmd.Parameters.Clear();
            checkAccountNameUpdateCmd.Parameters.AddWithValue("user_name_exist", user_name);
            checkAccountNameUpdateCmd.Parameters.AddWithValue("user_id", Session["user_id"].ToString());

            SqlDataAdapter adapterCheck = new SqlDataAdapter(checkAccountNameUpdateCmd);
            DataSet dataSetCheck = new DataSet();
            adapterCheck.Fill(dataSetCheck, dataKey);

            DataTable dataTableCheck = dataSetCheck.Tables[dataKey];

            if (dataTableCheck.Rows.Count == 0)
            {

                if (txtOldPassword.Text == "" && txtNewPassword.Text == "" && txtConfirmPassword.Text == "")
                {
                    updateProfileWithoutPasswordCmd.Parameters.Clear();
                    updateProfileWithoutPasswordCmd.Parameters.AddWithValue("user_id", (string)Session["user_id"]);
                    updateProfileWithoutPasswordCmd.Parameters.AddWithValue("user_name", user_name);
                    updateProfileWithoutPasswordCmd.Parameters.AddWithValue("user_email", user_email);
                    updateProfileWithoutPasswordCmd.Parameters.AddWithValue("user_description", user_description);

                    if (fileUploadImage.HasFile)
                    {
                        profile_image_filename = fileUploadImage.FileName;
                        fileUploadImage.SaveAs(MapPath("~/Images/ProfileImages/" + fileUploadImage.FileName));
                        profile_image_path = "~/Images/ProfileImages/" + profile_image_filename;
                    }
                    else
                    {
                        profile_image_path = imgProfile.ImageUrl;
                    }

                    updateProfileWithoutPasswordCmd.Parameters.AddWithValue("user_image", profile_image_path);

                    int rowsAffected = updateProfileWithoutPasswordCmd.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        connectSql.Close();
                        Response.Write("<script>window.alert('Update Successful!')</script>");
                        Response.Redirect("~/Forms/Dashboard" + (string)Session["privilege"] + ".aspx");
                    }
                    else
                    {
                        Response.Write("<script>window.alert('Update Failed!')</script>");
                    }
                }
                else
                {
                    DataRow dataRow = dataTable.Rows[0];
                    if (user_old_password == dataRow["Password"].ToString())
                    {
                        if (user_new_password == user_confirm_password)
                        {
                            updateProfileCmd.Parameters.Clear();
                            updateProfileCmd.Parameters.AddWithValue("user_id", (string)Session["user_id"]);
                            updateProfileCmd.Parameters.AddWithValue("user_name", user_name);
                            updateProfileCmd.Parameters.AddWithValue("user_password", user_new_password);
                            updateProfileCmd.Parameters.AddWithValue("user_email", user_email);
                            updateProfileCmd.Parameters.AddWithValue("user_description", user_description);

                            if (fileUploadImage.HasFile)
                            {
                                profile_image_filename = fileUploadImage.FileName;
                                fileUploadImage.SaveAs(MapPath("~/Images/ProfileImages/" + fileUploadImage.FileName));
                                profile_image_path = "~/Images/ProfileImages/" + profile_image_filename;
                            }
                            else
                            {
                                profile_image_path = imgProfile.ImageUrl;
                            }

                            updateProfileCmd.Parameters.AddWithValue("user_image", profile_image_path);

                            int rowsAffected = updateProfileCmd.ExecuteNonQuery();
                            if (rowsAffected > 0)
                            {
                                connectSql.Close();
                                Response.Write("<script>window.alert('Update Successful!')</script>");
                                Response.Redirect("~/Forms/Dashboard" + (string)Session["privilege"] + ".aspx");
                            }
                            else
                            {
                                Response.Write("<script>window.alert('Update Failed!')</script>");
                            }
                        }
                        else
                        {
                            Response.Write("<script>window.alert('Confirm Password not matched!')</script>");
                            txtOldPassword.Text = "";
                            txtNewPassword.Text = "";
                            txtConfirmPassword.Text = "";
                        }
                    }
                    else
                    {
                        Response.Write("<script>window.alert('Old Password Incorrect!')</script>");
                        txtOldPassword.Text = "";
                        txtNewPassword.Text = "";
                        txtConfirmPassword.Text = "";
                        return;
                    }
                }
            }
            else
            {
                Response.Write("<script>window.alert('Username existed!')</script>");
            }
        }

        private void loadDatabase()
        {
            string connectStr = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|AccountDatabase.mdf";
            connectSql = new SqlConnection(connectStr);

            try
            {
                connectSql.Open();
            }
            catch (SqlException ex)
            {
                Response.Write("<script>window.alert('SQL connection Failed!')</script>");
            }

            string displayProfileStr = "SELECT * FROM UserAccounts WHERE Id = @user_id";
            displayProfileCmd = new SqlCommand(displayProfileStr, connectSql);


            displayProfileCmd.Parameters.Clear();
            displayProfileCmd.Parameters.AddWithValue("user_id", (string)Session["user_id"]);

            adapter = new SqlDataAdapter(displayProfileCmd);
            dataSet = new DataSet();
            adapter.Fill(dataSet, dataKey);

            dataTable = dataSet.Tables[dataKey];

            if (dataTable.Rows.Count == 0)
            {
                //Just Do Nothing
            }
            else
            {
                if (!IsPostBack) {
                    DataRow dataRow = dataTable.Rows[0];
                    txtUserNameProfile.Text = dataRow["Name"].ToString();
                    txtEmailProfile.Text = dataRow["Email"].ToString();
                    txtDescription.Text = dataRow["Description"].ToString();

                    if (dataRow["ProfileImage"].ToString() != null)
                    {
                        imgProfile.ImageUrl = dataRow["ProfileImage"].ToString();
                    }
                }
            }
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            DataRow dataRow = dataTable.Rows[0];
            string user_privilege = (string)dataRow["Privileges"];

            connectSql.Close();
            Response.Redirect("~/Forms/Dashboard" + user_privilege + ".aspx");
        }

        protected void btnDisplay_Click(object sender, EventArgs e)
        {
            if (fileUploadImage.HasFile)
            {
                fileUploadImage.SaveAs(MapPath("~/Images/ProfileImages/" + fileUploadImage.FileName));
                imgProfile.ImageUrl = "~/Images/ProfileImages/" + fileUploadImage.FileName;
            }
        }

        protected void btnLogoutClick_Click(object sender, EventArgs e)
        {
            connectSql.Close();
            Session.Remove("user_name");
            Session.Remove("password");
            Session.Remove("privilege");
            Session.RemoveAll();
            Response.Redirect(Request.RawUrl);
        }

        protected void linkAdminPage_Click(object sender, EventArgs e)
        {
            connectSql.Close();
            Response.Redirect("~/Forms/Privileges/" + Session["privilege"].ToString() + "/AdministratorPage.aspx");
        }

        protected void linkBack_Click(object sender, EventArgs e)
        {
            connectSql.Close();
            Response.Redirect("~/Forms/Dashboard" + Session["privilege"].ToString() + ".aspx");
        }
    }
}