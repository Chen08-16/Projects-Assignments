﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;

namespace StockManagementSystem.Forms.Privileges.Users
{
    public partial class _3DRendererPage : System.Web.UI.Page
    {
        private SqlConnection connectSql;
        private SqlCommand searchStockCmd;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user_name"] != null && Session["password"] != null)
            {
                //Response.Write("<script>window.alert('Login Sucessful!')</script>"); testing line
                Response.ClearHeaders();
                Response.AddHeader("Cache-Control", "no-cache, no-store, max-age=0, must-revalidate");
                Response.AddHeader("Pragma", "no-cache");

                //Remove Administrator linkbutton if privilege is not Owner and Admin
                if ((string)Session["privilege"] != "Owner" && (string)Session["privilege"] != "Admin")
                {
                    linkAdminPage.Visible = false;
                }
            }
            else
            {
                Response.Write("<script>window.alert('Login Failed!')</script>");
                Response.Redirect("~/Forms/Login.aspx");
            }

            string connectStr = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|StockDatabase.mdf";
            connectSql = new SqlConnection(connectStr);

            try
            {
                connectSql.Open();
            }
            catch (SqlException ex)
            {
                Response.Write("<script>window.alert('SQL connection Failed!')</script>");
            }

            string value;
            string value2;

            string searchStockStr = "SELECT * FROM Stocks WHERE StockId = @stock_id";
            searchStockCmd = new SqlCommand(searchStockStr, connectSql);

            string dataKey = "Check";
            searchStockCmd.Parameters.Clear();
            searchStockCmd.Parameters.AddWithValue("stock_id", int.Parse((string)Session["stock_id"]));

            SqlDataAdapter adapter = new SqlDataAdapter(searchStockCmd);
            DataSet dataSet = new DataSet();
            adapter.Fill(dataSet, dataKey);

            DataTable dataTable = dataSet.Tables[dataKey];

            if (dataTable.Rows.Count == 0)
            {
                return;
            }
            else
            {
                DataRow dataRow = dataTable.Rows[0];
                value = (string)dataRow["Model3D"];
                value2 = (string)dataRow["Texture"];
            }

            string script = "<script type=\"text/javascript\">" +
                            "var value='" + value + "';" +
                            "var value2='" + value2 + "';" +
                            "</script>";

            ClientScriptManager clientSideScript = Page.ClientScript;

            if (!clientSideScript.IsClientScriptBlockRegistered(this.GetType(), "Var"))
            {
                clientSideScript.RegisterClientScriptBlock(this.GetType(), "Var", script);
            }
            connectSql.Close();
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Forms/Privileges/Users/StockDetailsPage.aspx");
        }

        protected void linkAdminPage_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Forms/Privileges/" + Session["privilege"].ToString() + "/AdministratorPage.aspx");
        }

        protected void linkLogout_Click(object sender, EventArgs e)
        {
            Session.Remove("user_name");
            Session.Remove("password");
            Session.Remove("privilege");
            Session.RemoveAll();
            Response.Redirect(Request.RawUrl);
        }

        protected void linkBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Forms/Dashboard" + Session["privilege"].ToString() + ".aspx");
        }
    }
}