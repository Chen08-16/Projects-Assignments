﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace StockManagementSystem.Forms
{
    public partial class CreateAccount : System.Web.UI.Page
    {
        private SqlConnection connectSql;
        private SqlCommand addAccountCmd;
        private SqlCommand checkAccountNameCmd;

        protected void Page_Load(object sender, EventArgs e)
        {
            string connectStr = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|AccountDatabase.mdf";
            connectSql = new SqlConnection(connectStr);

            try
            {
                connectSql.Open();
            }
            catch (SqlException ex)
            {
                Response.Write("<script>window.alert('SQL connection Failed!')</script>");
            }

            string addAccountStr = "INSERT INTO UserAccounts(Name, Password, Email, Privileges, ProfileImage) VALUES(@user_name, @password, @email, @privileges, @profile_image)";
            addAccountCmd = new SqlCommand(addAccountStr, connectSql);

            string checkAccountNameStr = "SELECT Name FROM UserAccounts WHERE Name = @user_name_exist";//"SELECT COUNT(Name) FROM UserAccounts WHERE Name = @user_name_exist";
            checkAccountNameCmd = new SqlCommand(checkAccountNameStr, connectSql);
        }

        protected void btnCreate_Click(object sender, EventArgs e)
        {
            string user_name = txtUserName.Text;
            string user_password = txtPassword.Text;
            string confirm_password = txtConfirmPassword.Text;
            string user_email = txtEmail.Text;
            string email = txtEmail.Text;
            string profile_image;
            string dataKey = "Check";

            if (user_name == "" || user_password == "")
            {
                Response.Write("<script>window.alert('Please Enter Username and Password.')</script>");
                return;
            }

            checkAccountNameCmd.Parameters.Clear();
            checkAccountNameCmd.Parameters.AddWithValue("user_name_exist", user_name);

            SqlDataAdapter adapter = new SqlDataAdapter(checkAccountNameCmd);
            DataSet dataSet = new DataSet();
            adapter.Fill(dataSet, dataKey);

            DataTable dataTable = dataSet.Tables[dataKey];

            if (dataTable.Rows.Count == 0)
            {

                if (user_password != confirm_password)
                {
                    Response.Write("<script>window.alert('Confirm password not matched!')</script>");
                    txtPassword.Text = "";
                    txtConfirmPassword.Text = "";
                    return;
                }

                addAccountCmd.Parameters.Clear();
                addAccountCmd.Parameters.AddWithValue("user_name", user_name);
                addAccountCmd.Parameters.AddWithValue("password", user_password);
                addAccountCmd.Parameters.AddWithValue("email", email);
                addAccountCmd.Parameters.AddWithValue("privileges", "User");

                string profile_image_filename;
                string profile_image_path;

                if (fileUploadImage.HasFile) {
                    profile_image_filename = fileUploadImage.FileName;
                    fileUploadImage.SaveAs(MapPath("~/Images/ProfileImages/" + fileUploadImage.FileName));
                    profile_image_path = "~/Images/ProfileImages/" + profile_image_filename;
                }
                else
                {
                    profile_image_path = imgProfile.ImageUrl;
                }

                addAccountCmd.Parameters.AddWithValue("profile_image", profile_image_path);

                int rowsAffected = addAccountCmd.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    connectSql.Close();
                    Response.Write("<script>window.alert('Create Account Successful!')</script>");
                    Response.Redirect("~/Forms/Dashboard.aspx");
                }
                else
                {
                    Response.Write("<script>window.alert('Create Account Failed!')</script>");
                }
            }
            else
            {

                Response.Write("<script>window.alert('Username existed!')</script>");
            }
        }

        protected void linkLogin_Click(object sender, EventArgs e)
        {
            connectSql.Close();
            Response.Redirect("~/Forms/Login.aspx");
        }

        //not use anymore
        protected void btnDisplay_Click(object sender, EventArgs e)
        {
            if (fileUploadImage.HasFile)
            {
                fileUploadImage.SaveAs(MapPath("~/Images/ProfileImages/" + fileUploadImage.FileName));
                imgProfile.ImageUrl = "~/Images/ProfileImages/" + fileUploadImage.FileName;
            }
        }

        public void DisplayImage()
        {
            Response.Redirect("~/Forms/Login.aspx");
        }
    }
}