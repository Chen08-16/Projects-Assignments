﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;

namespace StockManagementSystem.Forms
{
    public partial class Login : System.Web.UI.Page
    {
        private SqlConnection connectSql;
        private SqlCommand searchUserAccountCmd;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user_name"] != null && Session["password"] != null)
            {
                string user_privilege = (string)Session["privilege"];
                Response.Redirect("~/Forms/Dashboard" + user_privilege + ".aspx");
            }
            else
            {
                Response.ClearHeaders();
                Response.AddHeader("Cache-Control", "no-cache, no-store, max-age=0, must-revalidate");
                Response.AddHeader("Pragma", "no-cache");
            }

            string connectStr = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|AccountDatabase.mdf";
            connectSql = new SqlConnection(connectStr);

            try
            {
                connectSql.Open();
            }
            catch (SqlException ex)
            {
                Response.Write("<script>window.alert('SQL connection Failed!')</script>");
            }

            string searchUserAccountStr = "SELECT * FROM UserAccounts WHERE Name = @user_name AND Password = @password";
            searchUserAccountCmd = new SqlCommand(searchUserAccountStr, connectSql);
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string user_name = txtUserName.Text;
            string password = txtPassword.Text;

            if (user_name == "" || password == "")
            {
                Response.Write("<script>window.alert('Please Enter Username and Password.')</script>");
                return;
            }

            Session["user_name"] = user_name;
            Session["password"] = password;
            string dataKey = "Check";

            searchUserAccountCmd.Parameters.Clear();
            searchUserAccountCmd.Parameters.AddWithValue("user_name", (string)(Session["user_name"]));
            searchUserAccountCmd.Parameters.AddWithValue("password", (string)(Session["password"]));

            SqlDataAdapter adapter = new SqlDataAdapter(searchUserAccountCmd);
            DataSet dataSet = new DataSet();
            adapter.Fill(dataSet, dataKey);

            DataTable dataTable = dataSet.Tables[dataKey];

            if (dataTable.Rows.Count == 0)
            {
                Response.Write("<script>window.alert('Unable to login due to username or password invalid.')</script>");
                Session.Clear();
                return;
            }
            else
            {
                DataRow dataRow = dataTable.Rows[0];
                string user_privilege = (string)dataRow["Privileges"];
                Session["user_id"] = dataRow["Id"].ToString();
                Session["privilege"] = user_privilege;
                connectSql.Close();
                Response.Redirect("~/Forms/Dashboard" + user_privilege + ".aspx");
            }
        }

        protected void linkSignIn_Click(object sender, EventArgs e)
        {
            connectSql.Close();
            Response.Redirect("~/Forms/CreateAccount.aspx");
        }

        public void loginPageChecker()
        {

        }
    }
}