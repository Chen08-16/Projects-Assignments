﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace StockManagementSystem.Test
{
    public partial class Tab3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnClick(object sender, EventArgs e)
        {
            Response.Write("<script>window.alert('Hello Again!')</script>");
        }

        protected void btnClick_Click(object sender, EventArgs e)
        {
            Response.Write("<script>window.alert('Hello Again!')</script>");
        }
    }
}